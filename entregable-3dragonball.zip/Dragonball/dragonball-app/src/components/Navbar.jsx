import React from 'react';
import { AppBar, Toolbar, Button } from '@mui/material';
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <AppBar position="static">
      <Toolbar>
        <Button color="inherit" component={Link} to="/">Home</Button>
        <Button color="inherit" component={Link} to="/humans">Humanos</Button>
        <Button color="inherit" component={Link} to="/non-humans">No Humanos</Button>
        <Button color="inherit" component={Link} to="/about">Acerca de</Button>
      </Toolbar>
    </AppBar>
  );
}

export default Navbar;