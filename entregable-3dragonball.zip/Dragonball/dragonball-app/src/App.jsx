import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './components/Navbar';
import HomePage from './pages/HomePage';
import HumansPage from './pages/HumanPage';
import NonHumansPage from './pages/NonHumansPage';
import AboutPage from './pages/AboutPage';
import CharacterDetail from './components/CharacterDetail';
import './App.css';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/humans" element={<HumansPage />} />
        <Route path="/non-humans" element={<NonHumansPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/character/:id" element={<CharacterDetail />} />
      </Routes>
    </Router>
  );
}

export default App;