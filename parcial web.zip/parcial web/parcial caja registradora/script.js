let totalPagado = 0;
let cantidadComidas = 0;

document.getElementById('comprar').addEventListener('click', function() {
    const select = document.getElementById('comida');
    const comidaSeleccionada = select.options[select.selectedIndex].text;
    const precio = parseFloat(select.value);

    // Verificar que se haya seleccionado una comida
    if (precio > 0) {
        // Actualizar el total pagado y la cantidad de comidas
        totalPagado += precio;
        cantidadComidas += 1;

        // Mostrar total y cantidad
        document.getElementById('totalPagado').innerText = `Total Pagado: $${totalPagado}`;
        document.getElementById('cantidadComidas').innerText = `Cantidad de comidas compradas: ${cantidadComidas}`;

        // Agregar la comida comprada al combo box
        const comidasCompradas = document.getElementById('comidasCompradas');
        const nuevaOpcion = document.createElement('option');
        nuevaOpcion.text = comidaSeleccionada;
        comidasCompradas.add(nuevaOpcion);
    }
});
